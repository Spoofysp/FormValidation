package com.example.formvalidation;

public class item {

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public item(String name) {
        this.name = name;
    }
}
